---
Task ID: 3-7
Agent: full-stack-developer
Task: Build complete page with 4 skills, script toggle, and all components

Work Log:
- Rewrote /home/z/my-project/src/app/page.tsx completely (replacing old single-skill writing app)
- Added script toggle (Simplified 简体 HSK1 / Traditional 繁體 TOCFL1) in sticky header
- Added 4 skill tabs: Writing (✍️), Reading (📖), Listening (👂), Speaking (🗣️)
- Writing skill: HanziWriter integration with preview/quiz/idle modes, stroke progress dots, confetti on completion
- Reading skill: Multiple choice quiz showing Chinese word, 4 Vietnamese meaning options, auto-advance on correct
- Listening skill: TTS audio playback with play button, 4 Chinese word choices, show pinyin+meaning after answer
- Speaking skill: TTS reference audio, MediaRecorder recording, ASR recognition, result comparison
- Added Panda mascot with mood changes (idle/happy/sad/excited) and contextual speech bubbles
- Added gamification (XP per correct action, level progression, streak tracking) with progress bar
- Used useMemo for quiz choice generation to comply with Next.js 16 lint rules (no setState in effects)
- Used useCallback for all state reset logic triggered by user actions (not effects)
- Implemented TTS audio caching per word via useRef Map to avoid re-fetching
- Added skip/next navigation buttons for quiz skills
- Verified with lint: 0 errors, 0 warnings

Stage Summary:
- Complete Chinese learning app with 4 skills on a single page
- HSK 1 (Simplified) and TOCFL 1 (Traditional) vocab data integrated via script toggle
- TTS and ASR API routes connected for listening and speaking skills
- Responsive design with sticky header, scrollable topic/word tabs, warm amber/orange theme
- All state management properly handled to avoid cascading renders
