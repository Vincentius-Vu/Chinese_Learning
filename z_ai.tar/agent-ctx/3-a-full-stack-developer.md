---
Task ID: 3-a
Agent: full-stack-developer
Task: Build HanziWriter React wrapper component

Work Log:
- Created `/home/z/my-project/src/components/hanzi/HanziWriterCanvas.tsx` with full HanziWriter integration
- Created `/home/z/my-project/src/components/hanzi/index.ts` re-export file
- Analyzed hanzi-writer v3.7.3 type definitions from `node_modules/hanzi-writer/dist/types/index.esm.d.ts`
- Key findings from type analysis:
  - `strokeColor` is a string, not a function (no per-stroke color in create options)
  - `charDataLoader` supports both callback and Promise return styles
  - `quiz()` `onComplete` receives `{ character, totalMistakes }` (no strokesRemaining)
  - `animateCharacter()` `onComplete` receives `{ canceled }` 
  - `StrokeData` uses `mistakesOnStroke` (not `mistakesInStroke`)
  - Has `updateColor()` method for dynamic color changes
  - Has `setCharacter()` method for changing character without full recreation
- Component features:
  - Dynamic import of hanzi-writer to avoid SSR issues
  - Three modes: preview (animateCharacter), quiz (quiz), idle (outline only)
  - Proper cleanup: cancelQuiz + pauseAnimation on mode/char changes and unmount
  - Responsive sizing via useIsMobile hook (280x280 mobile, 320x320 desktop)
  - Rainbow stroke colors via updateColor after each correct stroke in quiz mode
  - Loading and error state overlays
  - Callback prop mapping from hanzi-writer internal types to clean component interface
  - charDataLoader fetches from `https://cdn.jsdelivr.net/npm/hanzi-writer-data@2.0/{char}.json`

Stage Summary:
- HanziWriterCanvas component ready for use
- Files created:
  - /home/z/my-project/src/components/hanzi/HanziWriterCanvas.tsx
  - /home/z/my-project/src/components/hanzi/index.ts
