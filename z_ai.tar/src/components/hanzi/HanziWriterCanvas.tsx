'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { useIsMobile } from '@/hooks/use-mobile';

// Stroke colors for rainbow-like gradient effect across strokes
const STROKE_COLORS = [
  '#e74c3c', '#e67e22', '#f1c40f', '#2ecc71', '#1abc9c',
  '#3498db', '#9b59b6', '#e91e63', '#00bcd4', '#8bc34a',
  '#ff5722', '#607d8b', '#795548',
];

// Import types from hanzi-writer (runtime import is dynamic to avoid SSR issues)
type HanziWriterInstance = {
  animateCharacter: (options?: { onComplete?: (res: { canceled: boolean }) => void }) => Promise<unknown>;
  quiz: (options?: Record<string, unknown>) => Promise<unknown>;
  showCharacter: (options?: { duration?: number; onComplete?: (res: { canceled: boolean }) => void }) => Promise<unknown>;
  hideCharacter: (options?: { duration?: number; onComplete?: (res: { canceled: boolean }) => void }) => Promise<unknown>;
  showOutline: (options?: { duration?: number; onComplete?: (res: { canceled: boolean }) => void }) => Promise<unknown>;
  hideOutline: (options?: { duration?: number; onComplete?: (res: { canceled: boolean }) => void }) => Promise<unknown>;
  cancelQuiz: () => void;
  pauseAnimation: () => Promise<unknown>;
  updateColor: (colorName: string, colorVal: string | null, options?: { duration?: number }) => Promise<unknown>;
  setCharacter: (char: string) => Promise<void>;
};

type HanziWriterStatic = {
  create: (
    element: string | HTMLElement,
    char: string,
    options?: Record<string, unknown>,
  ) => HanziWriterInstance;
};

export interface HanziWriterCanvasProps {
  /** The Chinese character to render */
  char: string;
  /** Current mode: 'preview' animates stroke order, 'quiz' lets user practice, 'idle' shows outline only */
  mode: 'preview' | 'quiz' | 'idle';
  /** Called when a stroke is drawn correctly in quiz mode */
  onStrokeCorrect?: (data: {
    strokeNum: number;
    mistakesInStroke: number;
    strokesRemaining: number;
    totalMistakes: number;
  }) => void;
  /** Called when the quiz is completed successfully */
  onComplete?: (data: { totalMistakes: number; strokesRemaining: number }) => void;
  /** Called when a mistake is made in quiz mode */
  onMistake?: (data: {
    strokeNum: number;
    mistakesInStroke: number;
    strokesRemaining: number;
    totalMistakes: number;
  }) => void;
}

export default function HanziWriterCanvas({
  char,
  mode,
  onStrokeCorrect,
  onComplete,
  onMistake,
}: HanziWriterCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const writerRef = useRef<HanziWriterInstance | null>(null);
  const HanziWriterModuleRef = useRef<HanziWriterStatic | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [moduleReady, setModuleReady] = useState(false);
  const isMobile = useIsMobile();

  // Keep callbacks in refs to avoid recreating writer when callbacks change
  const callbacksRef = useRef({ onStrokeCorrect, onComplete, onMistake });
  callbacksRef.current = { onStrokeCorrect, onComplete, onMistake };

  // Size based on viewport
  const size = isMobile ? 280 : 320;

  // Load HanziWriter module dynamically (SSR-safe)
  useEffect(() => {
    let cancelled = false;
    import('hanzi-writer').then((mod) => {
      if (!cancelled) {
        HanziWriterModuleRef.current = mod.default as unknown as HanziWriterStatic;
        setModuleReady(true);
      }
    }).catch((err) => {
      console.error('Failed to load hanzi-writer:', err);
      if (!cancelled) {
        setLoadError(true);
      }
    });
    return () => { cancelled = true; };
  }, []);

  // Create or recreate writer when char changes
  const createWriter = useCallback(() => {
    const HanziWriterModule = HanziWriterModuleRef.current;
    const container = containerRef.current;
    if (!HanziWriterModule || !container || !char) return;

    // Destroy existing writer
    if (writerRef.current) {
      try {
        writerRef.current.cancelQuiz();
        writerRef.current.pauseAnimation();
      } catch {
        // ignore errors during cleanup
      }
      writerRef.current = null;
    }

    // Clear the container content (hanzi-writer creates child elements)
    container.innerHTML = '';

    setIsLoading(true);
    setLoadError(false);

    try {
      const writer = HanziWriterModule.create(container, char, {
        width: size,
        height: size,
        padding: 20,
        showOutline: true,
        showCharacter: false,
        strokeAnimationSpeed: 1.2,
        delayBetweenStrokes: 300,
        strokeColor: STROKE_COLORS[0],
        outlineColor: '#ccc',
        drawingColor: '#333',
        highlightColor: '#e74c3c',
        radicalColor: '#168f16',
        highlightOnComplete: true,
        highlightCompleteColor: '#2ecc71',
        charDataLoader: (charToLoad: string) => {
          return fetch(
            `https://cdn.jsdelivr.net/npm/hanzi-writer-data@2.0/${charToLoad}.json`
          ).then((res) => {
            if (!res.ok) {
              throw new Error(`Failed to load character data for "${charToLoad}"`);
            }
            return res.json();
          });
        },
      });

      writerRef.current = writer;

      // Small delay to let the writer render, then mark as loaded
      requestAnimationFrame(() => {
        setIsLoading(false);
      });
    } catch (err) {
      console.error('Failed to create HanziWriter:', err);
      setLoadError(true);
      setIsLoading(false);
    }
  }, [char, size]);

  // Re-create writer when char or size changes (after module is loaded)
  useEffect(() => {
    if (!moduleReady) return;

    createWriter();

    return () => {
      if (writerRef.current) {
        try {
          writerRef.current.cancelQuiz();
          writerRef.current.pauseAnimation();
        } catch {
          // ignore
        }
        writerRef.current = null;
      }
    };
  }, [createWriter, moduleReady]);

  // Handle mode changes independently from writer creation
  useEffect(() => {
    const writer = writerRef.current;
    if (!writer) return;

    // Cancel any ongoing animation or quiz first
    try {
      writer.cancelQuiz();
      writer.pauseAnimation();
    } catch {
      // ignore
    }

    if (mode === 'preview') {
      writer.hideCharacter();
      writer.showOutline();
      writer.animateCharacter({
        onComplete: () => {
          // Show the character after animation completes
          writer.showCharacter({ duration: 300 });
        },
      });
    } else if (mode === 'quiz') {
      writer.hideCharacter();
      writer.showOutline();
      writer.quiz({
        onMistake: (data: { strokeNum: number; mistakesOnStroke: number; strokesRemaining: number; totalMistakes: number }) => {
          callbacksRef.current.onMistake?.({
            strokeNum: data.strokeNum,
            mistakesInStroke: data.mistakesOnStroke,
            strokesRemaining: data.strokesRemaining,
            totalMistakes: data.totalMistakes,
          });
        },
        onCorrectStroke: (data: { strokeNum: number; mistakesOnStroke: number; strokesRemaining: number; totalMistakes: number }) => {
          // Update stroke color for the next stroke in rainbow progression
          const nextColor = STROKE_COLORS[(data.strokeNum + 1) % STROKE_COLORS.length];
          try {
            writer.updateColor('strokeColor', nextColor);
          } catch {
            // color update is best-effort
          }
          callbacksRef.current.onStrokeCorrect?.({
            strokeNum: data.strokeNum,
            mistakesInStroke: data.mistakesOnStroke,
            strokesRemaining: data.strokesRemaining,
            totalMistakes: data.totalMistakes,
          });
        },
        onComplete: (summary: { totalMistakes: number }) => {
          // Show the completed character with highlight
          writer.showCharacter({ duration: 300 });
          callbacksRef.current.onComplete?.({
            totalMistakes: summary.totalMistakes,
            strokesRemaining: 0,
          });
        },
      });
    } else {
      // idle mode - show outline only, character hidden
      writer.hideCharacter();
      writer.showOutline();
    }
  }, [mode, char]); // re-run when mode or char changes

  return (
    <div className="relative inline-flex items-center justify-center">
      {/* Loading overlay */}
      {isLoading && moduleReady && (
        <div
          className="absolute inset-0 flex items-center justify-center rounded-lg z-10"
          style={{ width: size, height: size }}
        >
          <div className="flex flex-col items-center gap-2">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-muted border-t-primary" />
            <span className="text-sm text-muted-foreground">Đang tải...</span>
          </div>
        </div>
      )}
      {/* Error overlay */}
      {loadError && (
        <div
          className="absolute inset-0 flex items-center justify-center rounded-lg z-10"
          style={{ width: size, height: size }}
        >
          <div className="flex flex-col items-center gap-2 text-destructive">
            <span className="text-sm">Không thể tải dữ liệu chữ</span>
          </div>
        </div>
      )}
      {/* Writer mount point */}
      <div
        ref={containerRef}
        style={{ width: size, height: size }}
        className="rounded-lg bg-background border border-border"
      />
    </div>
  );
}
