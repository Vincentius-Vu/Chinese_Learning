// Gamification state management with localStorage persistence

export interface GameState {
  xp: number;
  level: number;
  streak: number;
  lastPracticeDate: string | null;
  totalCorrectStrokes: number;
  totalAttempts: number;
  totalCharsLearned: number;
  learnedChars: string[];
}

const STORAGE_KEY = "hanzi-game-state";

const XP_PER_LEVEL = 100;

function getInitialState(): GameState {
  return {
    xp: 0,
    level: 1,
    streak: 0,
    lastPracticeDate: null,
    totalCorrectStrokes: 0,
    totalAttempts: 0,
    totalCharsLearned: 0,
    learnedChars: [],
  };
}

export function loadGameState(): GameState {
  if (typeof window === "undefined") return getInitialState();
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      const parsed = JSON.parse(saved) as GameState;
      // Check streak - if last practice was more than 1 day ago, reset streak
      if (parsed.lastPracticeDate) {
        const lastDate = new Date(parsed.lastPracticeDate);
        const today = new Date();
        const diffDays = Math.floor(
          (today.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
        );
        if (diffDays > 1) {
          parsed.streak = 0;
        }
      }
      return parsed;
    }
  } catch {
    // ignore
  }
  return getInitialState();
}

export function saveGameState(state: GameState): void {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {
    // ignore
  }
}

export function addXP(state: GameState, amount: number): GameState {
  const newXp = state.xp + amount;
  const newLevel = Math.floor(newXp / XP_PER_LEVEL) + 1;
  return {
    ...state,
    xp: newXp,
    level: newLevel,
  };
}

export function getLevelProgress(state: GameState): number {
  const xpInLevel = state.xp % XP_PER_LEVEL;
  return (xpInLevel / XP_PER_LEVEL) * 100;
}

export function recordPractice(state: GameState): GameState {
  const today = new Date().toISOString().split("T")[0];
  let newStreak = state.streak;

  if (state.lastPracticeDate) {
    const lastDate = new Date(state.lastPracticeDate);
    const todayDate = new Date(today);
    const diffDays = Math.floor(
      (todayDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24)
    );
    if (diffDays === 1) {
      newStreak = state.streak + 1;
    } else if (diffDays === 0) {
      // Same day, keep streak
      newStreak = state.streak;
    } else {
      // Streak broken
      newStreak = 1;
    }
  } else {
    newStreak = 1;
  }

  return {
    ...state,
    streak: newStreak,
    lastPracticeDate: today,
  };
}

export function markCharLearned(state: GameState, hanzi: string): GameState {
  if (state.learnedChars.includes(hanzi)) return state;
  return {
    ...state,
    learnedChars: [...state.learnedChars, hanzi],
    totalCharsLearned: state.totalCharsLearned + 1,
  };
}
