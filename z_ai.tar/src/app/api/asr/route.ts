import type { NextRequest } from 'next/server';
import { NextResponse } from 'next/server';
import ZAI from 'z-ai-web-dev-sdk';

let zaiInstance: ZAI | null = null;

async function getZAI(): Promise<ZAI> {
  if (!zaiInstance) {
    zaiInstance = await ZAI.create();
  }
  return zaiInstance;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { audio } = body as { audio?: string };

    if (!audio || typeof audio !== 'string') {
      return NextResponse.json(
        { error: 'Audio is required and must be a base64-encoded string' },
        { status: 400 }
      );
    }

    const zai = await getZAI();

    const response = await zai.audio.asr.create({
      file_base64: audio,
    });

    return NextResponse.json({ text: response.text }, { status: 200 });
  } catch (error) {
    console.error('ASR API error:', error);
    return NextResponse.json(
      { error: 'Failed to recognize speech' },
      { status: 500 }
    );
  }
}
