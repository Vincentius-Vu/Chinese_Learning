'use client';

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { HanziWriterCanvas } from '@/components/hanzi';
import {
  type VocabWord,
  type ScriptType,
  type SkillType,
  getTopics,
  getDisplayChar,
  getAllWords,
} from '@/lib/vocab-data';
import {
  loadGameState,
  saveGameState,
  addXP,
  getLevelProgress,
  recordPractice,
  markCharLearned,
  type GameState,
} from '@/lib/game-store';
import confetti from 'canvas-confetti';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';

// ─── Constants ───
const SKILLS: { id: SkillType; emoji: string; label: string }[] = [
  { id: 'writing', emoji: '✍️', label: 'Viết' },
  { id: 'reading', emoji: '📖', label: 'Đọc' },
  { id: 'listening', emoji: '👂', label: 'Nghe' },
  { id: 'speaking', emoji: '🗣️', label: 'Nói' },
];

// ─── Panda SVG Component ───
function PandaAvatar({ mood }: { mood: 'happy' | 'sad' | 'idle' | 'excited' }) {
  const mouthPath =
    mood === 'happy'
      ? 'M47 62 Q50 67 53 62'
      : mood === 'excited'
        ? 'M46 61 Q50 68 54 61'
        : mood === 'sad'
          ? 'M46 65 Q50 61 54 65'
          : 'M47 62 Q50 65 53 62';
  const blushOpacity = mood === 'happy' || mood === 'excited' ? 0.7 : 0.3;

  return (
    <div className="panda-avatar" style={{ animation: mood === 'excited' ? 'panda-bounce 0.4s ease-out' : 'panda-idle 3s ease-in-out infinite' }}>
      <svg viewBox="0 0 100 100" className="w-full h-full">
        <circle cx="50" cy="55" r="33" fill="#ffffff" stroke="#21394f" strokeWidth="3" />
        <circle cx="23" cy="29" r="11" fill="#21394f" />
        <circle cx="77" cy="29" r="11" fill="#21394f" />
        <circle cx="23" cy="29" r="6" fill="#ead8bd" />
        <circle cx="77" cy="29" r="6" fill="#ead8bd" />
        <ellipse cx="38" cy="49" rx="8" ry="10" transform="rotate(-15 38 49)" fill="#21394f" />
        <ellipse cx="62" cy="49" rx="8" ry="10" transform="rotate(15 62 49)" fill="#21394f" />
        <circle cx="39" cy="48" r="3" fill="#ffffff" />
        <circle cx="61" cy="48" r="3" fill="#ffffff" />
        <circle cx="39" cy="48" r="1.2" fill="#21394f" />
        <circle cx="61" cy="48" r="1.2" fill="#21394f" />
        <ellipse cx="50" cy="58" rx="4.5" ry="3" fill="#21394f" />
        <path d={mouthPath} fill="none" stroke="#21394f" strokeWidth="2.5" strokeLinecap="round" />
        <circle cx="26" cy="57" r="3.5" fill="#f3d1cc" opacity={blushOpacity} />
        <circle cx="74" cy="57" r="3.5" fill="#f3d1cc" opacity={blushOpacity} />
      </svg>
    </div>
  );
}

// ─── Mascot messages ───
const MASCOT_MESSAGES = {
  idle: [
    'Học tiếng Trung thật dễ! Hãy cùng tớ thử sức nào! 🐼',
    'Chọn một kỹ năng để bắt đầu học nhé! ✏️',
    'Học mỗi ngày một chút, giỏi mỗi ngày một nhiều! 📖',
  ],
  correct: [
    'Tuyệt vời! Bạn làm đúng rồi! 🎉',
    'Xuất sắc! Tiếp tục nào! ⭐',
    'Giỏi quá! Cố lên! 🔥',
  ],
  wrong: [
    'Không sao, thử lại nhé! 💪',
    'Gần đúng rồi, cố lên! 🤗',
    'Sai chút xíu thôi, làm lại nào! 🌈',
  ],
  complete: [
    'Hoàn thành xuất sắc! Bạn thật giỏi! 🏆',
    'Chúc mừng! Tiếp tục nào! 🎊',
    'Tuyệt vời! Luyện tập tiếp nhé! 🚀',
  ],
};

function getRandomMessage(category: keyof typeof MASCOT_MESSAGES): string {
  const messages = MASCOT_MESSAGES[category];
  return messages[Math.floor(Math.random() * messages.length)];
}

// ─── Helper: Get random wrong choices for quizzes ───
function getRandomChoices<T>(correct: T, all: T[], count: number): T[] {
  const filtered = all.filter(item => item !== correct);
  const shuffled = filtered.sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
}

// ─── TTS helper ───
async function fetchTTS(text: string): Promise<string> {
  const res = await fetch('/api/tts', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ text, voice: 'tongtong', speed: 0.8 }),
  });
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

function playAudio(url: string): Promise<void> {
  return new Promise((resolve) => {
    const audio = new Audio(url);
    audio.onended = () => resolve();
    audio.onerror = () => resolve();
    audio.play().catch(() => resolve());
  });
}

// ─── Seed-based shuffle for deterministic quiz choices per word ───
function seededShuffle<T>(arr: T[], seed: string): T[] {
  const result = [...arr];
  let hash = 0;
  for (let i = 0; i < seed.length; i++) {
    hash = ((hash << 5) - hash + seed.charCodeAt(i)) | 0;
  }
  for (let i = result.length - 1; i > 0; i--) {
    hash = ((hash << 5) - hash + i) | 0;
    const j = Math.abs(hash) % (i + 1);
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

// ─── Main Component ───
export default function Home() {
  // Core state
  const [script, setScript] = useState<ScriptType>('simplified');
  const [skill, setSkill] = useState<SkillType>('writing');
  const [gameState, setGameState] = useState<GameState>(() => {
    if (typeof window === 'undefined') {
      return {
        xp: 0, level: 1, streak: 0, lastPracticeDate: null,
        totalCorrectStrokes: 0, totalAttempts: 0, totalCharsLearned: 0, learnedChars: [],
      };
    }
    return loadGameState();
  });

  // Derived data
  const topics = useMemo(() => getTopics(script), [script]);
  const allWords = useMemo(() => getAllWords(script), [script]);

  // Topic & word selection
  const [activeTopicId, setActiveTopicId] = useState<string>(topics[0].id);
  const activeTopic = useMemo(
    () => topics.find(t => t.id === activeTopicId) || topics[0],
    [topics, activeTopicId]
  );

  // Writing skill: only single-char words with strokes
  const writingWords = useMemo(
    () => activeTopic.words.filter(w => {
      const char = getDisplayChar(w, script);
      return char.length === 1 && w.strokes && w.strokes > 0;
    }),
    [activeTopic, script]
  );

  // All words for current topic (for reading/listening/speaking)
  const topicWords = activeTopic.words;

  // Get the appropriate word list for current skill
  const currentWordList = skill === 'writing' ? writingWords : topicWords;

  const [activeWordIndex, setActiveWordIndex] = useState(0);
  const activeWord = currentWordList[activeWordIndex] || currentWordList[0];

  // Panda & mascot
  const [pandaMood, setPandaMood] = useState<'happy' | 'sad' | 'idle' | 'excited'>('idle');
  const [mascotMsg, setMascotMsg] = useState(getRandomMessage('idle'));
  const pandaTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Help dialog
  const [helpOpen, setHelpOpen] = useState(false);

  // ─── WRITING STATE ───
  const [writeMode, setWriteMode] = useState<'idle' | 'preview' | 'quiz'>('idle');
  const [writeCompletedStrokes, setWriteCompletedStrokes] = useState(0);
  const [writeQuizMistakes, setWriteQuizMistakes] = useState(0);
  const [writeIsComplete, setWriteIsComplete] = useState(false);
  const confettiShownRef = useRef(false);

  // ─── READING STATE ───
  const [readAnswer, setReadAnswer] = useState<'correct' | 'wrong' | null>(null);
  const [readCorrect, setReadCorrect] = useState(0);
  const [readTotal, setReadTotal] = useState(0);
  const [readShowPinyin, setReadShowPinyin] = useState(false);

  // ─── LISTENING STATE ───
  const [listenAnswer, setListenAnswer] = useState<'correct' | 'wrong' | null>(null);
  const [listenCorrect, setListenCorrect] = useState(0);
  const [listenTotal, setListenTotal] = useState(0);
  const [listenShowInfo, setListenShowInfo] = useState(false);
  const [listenAudioLoading, setListenAudioLoading] = useState(false);
  const [listenPlaying, setListenPlaying] = useState(false);
  const ttsCacheRef = useRef<Map<string, string>>(new Map());

  // ─── SPEAKING STATE ───
  const [speakRecording, setSpeakRecording] = useState(false);
  const [speakResult, setSpeakResult] = useState<'correct' | 'wrong' | null>(null);
  const [speakRecognized, setSpeakRecognized] = useState('');
  const [speakLoading, setSpeakLoading] = useState(false);
  const [speakAudioLoading, setSpeakAudioLoading] = useState(false);
  const [speakPlaying, setSpeakPlaying] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);

  // ─── Derived: Reading quiz choices (memoized) ───
  const readChoices = useMemo(() => {
    if (!activeWord) return [];
    const allVietnamese = allWords.map(w => w.vietnamese);
    const wrongChoices = getRandomChoices(activeWord.vietnamese, allVietnamese, 3);
    return seededShuffle([...wrongChoices, activeWord.vietnamese], activeWord.simplified + '-read');
  }, [activeWord, allWords]);

  // ─── Derived: Listening quiz choices (memoized) ───
  const listenChoices = useMemo(() => {
    if (!activeWord) return [];
    const wrongChoices = getRandomChoices(activeWord, allWords, 3);
    return seededShuffle([...wrongChoices, activeWord], activeWord.simplified + '-listen');
  }, [activeWord, allWords]);

  // ─── Save game state ───
  useEffect(() => {
    saveGameState(gameState);
  }, [gameState]);

  // ─── Reset skill state helper ───
  const resetSkillState = useCallback(() => {
    // Writing
    setWriteMode('idle');
    setWriteCompletedStrokes(0);
    setWriteQuizMistakes(0);
    setWriteIsComplete(false);
    confettiShownRef.current = false;
    // Reading
    setReadAnswer(null);
    setReadShowPinyin(false);
    // Listening
    setListenAnswer(null);
    setListenShowInfo(false);
    setListenAudioLoading(false);
    setListenPlaying(false);
    // Speaking
    setSpeakRecording(false);
    setSpeakResult(null);
    setSpeakRecognized('');
    setSpeakLoading(false);
    setSpeakAudioLoading(false);
    setSpeakPlaying(false);
    // Panda
    setPandaMood('idle');
    setMascotMsg(getRandomMessage('idle'));
  }, []);

  // ─── Handle script change ───
  const handleScriptChange = useCallback((newScript: ScriptType) => {
    setScript(newScript);
    const newTopics = getTopics(newScript);
    setActiveTopicId(newTopics[0].id);
    setActiveWordIndex(0);
    resetSkillState();
  }, [resetSkillState]);

  // ─── Handle skill change ───
  const handleSkillChange = useCallback((newSkill: SkillType) => {
    setSkill(newSkill);
    setActiveWordIndex(0);
    resetSkillState();
  }, [resetSkillState]);

  // ─── Handle topic change ───
  const handleTopicChange = useCallback((topicId: string) => {
    setActiveTopicId(topicId);
    setActiveWordIndex(0);
    resetSkillState();
  }, [resetSkillState]);

  // ─── Handle word selection ───
  const handleWordSelect = useCallback((idx: number) => {
    setActiveWordIndex(idx);
    // Reset current skill state
    setReadAnswer(null);
    setReadShowPinyin(false);
    setListenAnswer(null);
    setListenShowInfo(false);
    setWriteMode('idle');
    setWriteCompletedStrokes(0);
    setWriteQuizMistakes(0);
    setWriteIsComplete(false);
    confettiShownRef.current = false;
    setSpeakResult(null);
    setSpeakRecognized('');
    setSpeakRecording(false);
    setSpeakLoading(false);
  }, []);

  // ─── Panda mood helper ───
  const setPandaMoodTemp = useCallback((mood: 'happy' | 'sad' | 'excited', duration = 800) => {
    setPandaMood(mood);
    if (pandaTimerRef.current) clearTimeout(pandaTimerRef.current);
    pandaTimerRef.current = setTimeout(() => setPandaMood('idle'), duration);
  }, []);

  // ─── WRITING HANDLERS ───
  const handleWritePreview = useCallback(() => {
    setWriteMode('preview');
    setWriteIsComplete(false);
    setWriteCompletedStrokes(0);
    setWriteQuizMistakes(0);
    confettiShownRef.current = false;
    setMascotMsg('Xem kỹ thứ tự nét bút nhé! 👀');
    setPandaMood('idle');
  }, []);

  const handleWriteQuiz = useCallback(() => {
    setWriteMode('quiz');
    setWriteIsComplete(false);
    setWriteCompletedStrokes(0);
    setWriteQuizMistakes(0);
    confettiShownRef.current = false;
    setMascotMsg('Đến lượt bạn viết rồi! Cố lên! 💪');
    setPandaMood('idle');
  }, []);

  const handleWriteReset = useCallback(() => {
    setWriteMode('idle');
    setWriteIsComplete(false);
    setWriteCompletedStrokes(0);
    setWriteQuizMistakes(0);
    confettiShownRef.current = false;
    setMascotMsg(getRandomMessage('idle'));
    setPandaMood('idle');
  }, []);

  const handleStrokeCorrect = useCallback(
    (data: { strokeNum: number; strokesRemaining: number; totalMistakes: number }) => {
      const newCompleted = data.strokeNum + 1;
      setWriteCompletedStrokes(newCompleted);
      if (data.totalMistakes === 0) {
        setMascotMsg(getRandomMessage('correct'));
      }
      setPandaMoodTemp('happy');
      setGameState(prev => addXP(prev, 5));
    },
    [setPandaMoodTemp]
  );

  const handleMistake = useCallback(
    (data: { totalMistakes: number }) => {
      setWriteQuizMistakes(data.totalMistakes);
      setMascotMsg(getRandomMessage('wrong'));
      setPandaMoodTemp('sad');
    },
    [setPandaMoodTemp]
  );

  const handleWriteComplete = useCallback(
    (data: { totalMistakes: number }) => {
      setWriteIsComplete(true);
      setMascotMsg(getRandomMessage('complete'));
      setPandaMoodTemp('excited', 1500);
      const char = getDisplayChar(activeWord, script);
      setGameState(prev => {
        let updated = addXP(prev, 20);
        updated = markCharLearned(updated, char);
        updated = recordPractice(updated);
        return updated;
      });
      if (!confettiShownRef.current) {
        confettiShownRef.current = true;
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.6 },
          colors: ['#e74c3c', '#e67e22', '#f1c40f', '#2ecc71', '#3498db', '#9b59b6'],
        });
        setTimeout(() => {
          confetti({ particleCount: 40, angle: 60, spread: 55, origin: { x: 0 }, colors: ['#e74c3c', '#e67e22', '#f1c40f', '#2ecc71'] });
          confetti({ particleCount: 40, angle: 120, spread: 55, origin: { x: 1 }, colors: ['#e74c3c', '#e67e22', '#f1c40f', '#2ecc71'] });
        }, 250);
      }
    },
    [activeWord, script, setPandaMoodTemp]
  );

  // ─── READING HANDLER ───
  const handleReadAnswer = useCallback(
    (choice: string) => {
      if (readAnswer) return;
      const isCorrect = choice === activeWord.vietnamese;
      setReadAnswer(isCorrect ? 'correct' : 'wrong');
      setReadShowPinyin(true);
      setReadTotal(prev => prev + 1);

      if (isCorrect) {
        setReadCorrect(prev => prev + 1);
        setPandaMoodTemp('happy');
        setMascotMsg(getRandomMessage('correct'));
        setGameState(prev => {
          let updated = addXP(prev, 10);
          updated = recordPractice(updated);
          return updated;
        });
      } else {
        setPandaMoodTemp('sad');
        setMascotMsg(getRandomMessage('wrong'));
      }
    },
    [readAnswer, activeWord, setPandaMoodTemp]
  );

  // ─── LISTENING HANDLERS ───
  const handleListenPlay = useCallback(async () => {
    if (!activeWord || listenAudioLoading || listenPlaying) return;
    const text = getDisplayChar(activeWord, script);

    try {
      let audioUrl = ttsCacheRef.current.get(text);
      if (!audioUrl) {
        setListenAudioLoading(true);
        audioUrl = await fetchTTS(text);
        ttsCacheRef.current.set(text, audioUrl);
      }
      setListenAudioLoading(false);
      setListenPlaying(true);
      await playAudio(audioUrl);
      setListenPlaying(false);
    } catch {
      setListenAudioLoading(false);
      setListenPlaying(false);
    }
  }, [activeWord, script, listenAudioLoading, listenPlaying]);

  const handleListenAnswer = useCallback(
    (choice: VocabWord) => {
      if (listenAnswer) return;
      const isCorrect = choice.simplified === activeWord.simplified;
      setListenAnswer(isCorrect ? 'correct' : 'wrong');
      setListenShowInfo(true);
      setListenTotal(prev => prev + 1);

      if (isCorrect) {
        setListenCorrect(prev => prev + 1);
        setPandaMoodTemp('happy');
        setMascotMsg(getRandomMessage('correct'));
        setGameState(prev => {
          let updated = addXP(prev, 10);
          updated = recordPractice(updated);
          return updated;
        });
      } else {
        setPandaMoodTemp('sad');
        setMascotMsg(getRandomMessage('wrong'));
      }
    },
    [listenAnswer, activeWord, setPandaMoodTemp]
  );

  // ─── SPEAKING HANDLERS ───
  const handleSpeakPlay = useCallback(async () => {
    if (!activeWord || speakAudioLoading || speakPlaying) return;
    const text = getDisplayChar(activeWord, script);

    try {
      let audioUrl = ttsCacheRef.current.get(text);
      if (!audioUrl) {
        setSpeakAudioLoading(true);
        audioUrl = await fetchTTS(text);
        ttsCacheRef.current.set(text, audioUrl);
      }
      setSpeakAudioLoading(false);
      setSpeakPlaying(true);
      await playAudio(audioUrl);
      setSpeakPlaying(false);
    } catch {
      setSpeakAudioLoading(false);
      setSpeakPlaying(false);
    }
  }, [activeWord, script, speakAudioLoading, speakPlaying]);

  const handleStartRecording = useCallback(async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream, { mimeType: 'audio/webm' });
      chunksRef.current = [];
      mediaRecorder.ondataavailable = (e) => chunksRef.current.push(e.data);
      mediaRecorder.start();
      mediaRecorderRef.current = mediaRecorder;
      setSpeakRecording(true);
      setSpeakResult(null);
      setSpeakRecognized('');
    } catch {
      setMascotMsg('Không thể truy cập micro. Vui lòng cho phép truy cập! 🎤');
    }
  }, []);

  const handleStopRecording = useCallback(async () => {
    const mr = mediaRecorderRef.current;
    if (!mr) return;

    setSpeakRecording(false);
    setSpeakLoading(true);

    const base64 = await new Promise<string>((resolve) => {
      mr.onstop = () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.onloadend = () => {
          const result = (reader.result as string).split(',')[1];
          resolve(result || '');
        };
        reader.readAsDataURL(blob);
        mr.stream.getTracks().forEach(t => t.stop());
      };
      mr.stop();
    });

    if (!base64) {
      setSpeakLoading(false);
      return;
    }

    try {
      const res = await fetch('/api/asr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ audio: base64 }),
      });
      const data = await res.json();
      const recognized = data.text || '';
      setSpeakRecognized(recognized);
      setSpeakLoading(false);

      const targetChar = getDisplayChar(activeWord, script);
      const isCorrect = recognized.trim() === targetChar || recognized.includes(targetChar);
      setSpeakResult(isCorrect ? 'correct' : 'wrong');

      if (isCorrect) {
        setPandaMoodTemp('excited', 1500);
        setMascotMsg(getRandomMessage('correct'));
        setGameState(prev => {
          let updated = addXP(prev, 15);
          updated = recordPractice(updated);
          return updated;
        });
        confetti({
          particleCount: 60,
          spread: 50,
          origin: { y: 0.6 },
          colors: ['#e74c3c', '#e67e22', '#f1c40f', '#2ecc71'],
        });
      } else {
        setPandaMoodTemp('sad');
        setMascotMsg(getRandomMessage('wrong'));
      }
    } catch {
      setSpeakLoading(false);
      setSpeakResult('wrong');
      setSpeakRecognized('');
    }
  }, [activeWord, script, setPandaMoodTemp]);

  // ─── Derived values ───
  const levelProgress = getLevelProgress(gameState);
  const displayChar = activeWord ? getDisplayChar(activeWord, script) : '';

  // ─── Next word helper ───
  const goNextWord = useCallback(() => {
    if (activeWordIndex < currentWordList.length - 1) {
      const nextIdx = activeWordIndex + 1;
      handleWordSelect(nextIdx);
    }
  }, [activeWordIndex, currentWordList.length, handleWordSelect]);

  // ─── RENDER: Header ───
  const renderHeader = () => (
    <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-amber-100 shadow-sm">
      <div className="max-w-2xl mx-auto px-4 py-3">
        {/* Title */}
        <div className="flex items-center justify-center gap-2 mb-2">
          <span className="text-2xl">🦉</span>
          <h1 className="text-xl font-extrabold text-gray-800">
            Luyện Tập <span className="text-amber-600">Chữ Hán</span>
          </h1>
        </div>

        {/* Script Toggle */}
        <div className="flex justify-center gap-2 mb-2">
          <Button
            size="sm"
            variant={script === 'simplified' ? 'default' : 'outline'}
            className={`text-xs px-4 ${script === 'simplified' ? 'bg-amber-500 hover:bg-amber-600 text-white' : 'hover:bg-amber-50 hover:border-amber-300'}`}
            onClick={() => handleScriptChange('simplified')}
          >
            简体 <span className="ml-1 opacity-80">HSK1</span>
          </Button>
          <Button
            size="sm"
            variant={script === 'traditional' ? 'default' : 'outline'}
            className={`text-xs px-4 ${script === 'traditional' ? 'bg-amber-500 hover:bg-amber-600 text-white' : 'hover:bg-amber-50 hover:border-amber-300'}`}
            onClick={() => handleScriptChange('traditional')}
          >
            繁體 <span className="ml-1 opacity-80">TOCFL1</span>
          </Button>
        </div>

        {/* Stats */}
        <div className="flex items-center justify-center gap-3 flex-wrap">
          <Badge variant="outline" className="bg-orange-50 border-orange-200 text-orange-700 text-xs gap-1">
            🔥 <span className="font-bold">{gameState.streak}</span> ngày
          </Badge>
          <Badge variant="outline" className="bg-yellow-50 border-yellow-200 text-yellow-700 text-xs gap-1">
            ✨ <span className="font-bold">{gameState.xp}</span> XP
          </Badge>
          <Badge variant="outline" className="bg-emerald-50 border-emerald-200 text-emerald-700 text-xs gap-1">
            🎓 Cấp <span className="font-bold">{gameState.level}</span>
          </Badge>
          <Dialog open={helpOpen} onOpenChange={setHelpOpen}>
            <DialogTrigger asChild>
              <Button variant="ghost" size="sm" className="h-7 px-2 text-xs text-gray-500 hover:text-gray-700">
                ❓ Hướng dẫn
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle className="text-lg font-bold text-gray-800">
                  🎨 Hướng dẫn sử dụng
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-3 py-2">
                <div className="text-sm text-gray-600 space-y-2">
                  <p><strong>✍️ Viết:</strong> Luyện viết chữ Hán theo đúng thứ tự nét bút.</p>
                  <p><strong>📖 Đọc:</strong> Chọn nghĩa tiếng Việt đúng cho từ tiếng Trung.</p>
                  <p><strong>👂 Nghe:</strong> Nghe âm thanh và chọn từ tiếng Trung đúng.</p>
                  <p><strong>🗣️ Nói:</strong> Luyện phát âm và so sánh với âm thanh mẫu.</p>
                  <p><strong>简体/繁體:</strong> Chuyển đổi giữa chữ giản thể (HSK1) và phồn thể (TOCFL1).</p>
                </div>
              </div>
              <Button
                className="w-full bg-amber-500 hover:bg-amber-600 text-white"
                onClick={() => setHelpOpen(false)}
              >
                Bắt đầu học ngay!
              </Button>
            </DialogContent>
          </Dialog>
        </div>

        {/* Level progress bar */}
        <div className="mt-2">
          <Progress value={levelProgress} className="h-1.5 bg-amber-100 [&>div]:bg-amber-500" />
        </div>
      </div>
    </header>
  );

  // ─── RENDER: Skill Tabs ───
  const renderSkillTabs = () => (
    <div className="flex justify-center gap-2">
      {SKILLS.map(s => (
        <Button
          key={s.id}
          size="sm"
          variant={skill === s.id ? 'default' : 'outline'}
          className={`text-xs px-3 ${skill === s.id ? 'bg-amber-500 hover:bg-amber-600 text-white' : 'hover:bg-amber-50 hover:border-amber-300'}`}
          onClick={() => handleSkillChange(s.id)}
        >
          {s.emoji} {s.label}
        </Button>
      ))}
    </div>
  );

  // ─── RENDER: Topic Tabs ───
  const renderTopicTabs = () => (
    <ScrollArea className="w-full whitespace-nowrap">
      <div className="flex gap-2 pb-1">
        {topics.map(topic => (
          <Button
            key={topic.id}
            size="sm"
            variant={activeTopicId === topic.id ? 'default' : 'outline'}
            className={`shrink-0 text-xs ${activeTopicId === topic.id ? 'bg-amber-500 hover:bg-amber-600 text-white' : 'hover:bg-amber-50 hover:border-amber-300'}`}
            onClick={() => handleTopicChange(topic.id)}
          >
            {topic.emoji} {topic.label_vi}
          </Button>
        ))}
      </div>
      <ScrollBar orientation="horizontal" />
    </ScrollArea>
  );

  // ─── RENDER: Word Selector ───
  const renderWordSelector = () => {
    if (currentWordList.length === 0) {
      return (
        <div className="text-center text-sm text-gray-500 py-4">
          {skill === 'writing'
            ? 'Chủ đề này chưa có chữ đơn để luyện viết. Hãy chọn chủ đề khác!'
            : 'Chưa có từ vựng trong chủ đề này.'}
        </div>
      );
    }

    return (
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex gap-2 pb-1">
          {currentWordList.map((word, idx) => {
            const char = getDisplayChar(word, script);
            const isActive = idx === activeWordIndex;
            const isLearned = gameState.learnedChars.includes(char);
            return (
              <Button
                key={`${word.simplified}-${idx}`}
                size="sm"
                variant={isActive ? 'default' : 'outline'}
                className={`shrink-0 h-auto py-2 px-3 flex-col gap-0.5 min-w-[52px] ${
                  isActive
                    ? 'bg-amber-500 hover:bg-amber-600 text-white'
                    : isLearned
                      ? 'bg-emerald-50 border-emerald-200 text-emerald-700 hover:bg-emerald-100'
                      : 'hover:bg-amber-50 hover:border-amber-300'
                }`}
                onClick={() => handleWordSelect(idx)}
              >
                <span className="text-base font-serif">{char}</span>
                <span className="text-[9px] opacity-70 truncate max-w-[44px]">{word.vietnamese}</span>
              </Button>
            );
          })}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    );
  };

  // ─── RENDER: Panda Mascot ───
  const renderPanda = () => (
    <div className="flex items-start gap-3 px-5 py-3 bg-amber-50/50">
      <div className="w-14 h-14 shrink-0">
        <PandaAvatar mood={pandaMood} />
      </div>
      <div className="flex-1 bg-white rounded-2xl rounded-tl-sm px-4 py-3 shadow-sm border border-amber-100">
        <p className="text-sm text-gray-700 leading-relaxed">{mascotMsg}</p>
      </div>
    </div>
  );

  // ─── RENDER: Writing Skill ───
  const renderWritingSkill = () => {
    if (!activeWord || writingWords.length === 0) {
      return (
        <div className="text-center py-10 text-gray-500">
          <div className="text-4xl mb-2">✍️</div>
          <p>Chọn chủ đề có chữ đơn để luyện viết</p>
        </div>
      );
    }

    const char = getDisplayChar(activeWord, script);
    const modeBadgeText =
      writeMode === 'idle' ? 'Sẵn sàng' : writeMode === 'preview' ? 'Xem nét bút' : 'Luyện viết';

    return (
      <div className="space-y-0">
        {/* Mode badge */}
        <div className="flex justify-center pt-4">
          <Badge
            className={`text-xs px-3 py-1 ${
              writeMode === 'quiz'
                ? 'bg-emerald-100 text-emerald-700'
                : writeMode === 'preview'
                  ? 'bg-blue-100 text-blue-700'
                  : 'bg-gray-100 text-gray-600'
            }`}
          >
            {modeBadgeText}
          </Badge>
        </div>

        {/* Character info */}
        <div className="text-center py-3">
          <div className="text-5xl font-serif text-gray-800 mb-1">{char}</div>
          <div className="text-lg text-amber-600 font-semibold">{activeWord.pinyin}</div>
          <div className="text-sm text-gray-500">{activeWord.vietnamese}</div>
          {activeWord.strokes && (
            <Badge variant="outline" className="mt-1 text-xs text-gray-400">
              {activeWord.strokes} nét
            </Badge>
          )}
        </div>

        {/* HanziWriter Canvas */}
        <div className="flex justify-center relative">
          <HanziWriterCanvas
            char={char}
            mode={writeMode}
            onStrokeCorrect={handleStrokeCorrect}
            onComplete={handleWriteComplete}
            onMistake={handleMistake}
          />
          {writeIsComplete && (
            <div className="absolute inset-0 flex items-center justify-center bg-white/60 backdrop-blur-sm rounded-lg animate-fade-in">
              <div className="text-center">
                <div className="text-5xl mb-2">⭐</div>
                <div className="text-xl font-bold text-amber-600">Hoàn thành!</div>
                <div className="text-sm text-gray-500">
                  {activeWord.strokes} nét · {writeQuizMistakes} lần sai
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Stroke progress dots */}
        {writeMode === 'quiz' && !writeIsComplete && activeWord.strokes && (
          <div className="flex justify-center gap-1.5 py-3 px-4 flex-wrap">
            {Array.from({ length: activeWord.strokes }).map((_, i) => (
              <div
                key={i}
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all duration-300 ${
                  i < writeCompletedStrokes
                    ? 'bg-emerald-500 text-white scale-100'
                    : i === writeCompletedStrokes
                      ? 'bg-amber-400 text-white scale-110 ring-2 ring-amber-200'
                      : 'bg-gray-100 text-gray-400'
                }`}
              >
                {i + 1}
              </div>
            ))}
          </div>
        )}

        {/* Status */}
        <div className="px-5 py-2">
          <div
            className={`text-center text-sm px-4 py-2 rounded-lg ${
              writeIsComplete
                ? 'bg-emerald-50 text-emerald-700'
                : writeMode === 'quiz'
                  ? 'bg-amber-50 text-amber-700'
                  : 'bg-gray-50 text-gray-500'
            }`}
          >
            {writeIsComplete
              ? `⭐ Hoàn thành! ${activeWord.strokes} nét · ${writeQuizMistakes} lần sai`
              : writeMode === 'quiz'
                ? `✏️ Viết nét ${writeCompletedStrokes + 1} / ${activeWord.strokes}`
                : writeMode === 'preview'
                  ? '🖌️ Đang xem thứ tự nét bút...'
                  : '⏳ Chọn "Xem nét" hoặc "Luyện viết" để bắt đầu'}
          </div>
        </div>

        {/* Progress bar */}
        {writeMode === 'quiz' && activeWord.strokes && (
          <div className="px-5 py-2">
            <div className="flex justify-between text-xs text-gray-500 mb-1">
              <span>Tiến độ viết</span>
              <span>{writeCompletedStrokes} / {activeWord.strokes}</span>
            </div>
            <Progress
              value={(writeCompletedStrokes / activeWord.strokes) * 100}
              className="h-2 bg-gray-100 [&>div]:bg-emerald-500"
            />
          </div>
        )}

        <Separator className="mx-5" />

        {/* Controls */}
        <div className="flex justify-center gap-3 p-4 flex-wrap">
          <Button
            variant="outline"
            className="gap-1.5 border-amber-200 hover:bg-amber-50 hover:text-amber-700"
            onClick={handleWritePreview}
            disabled={writeMode === 'preview'}
          >
            🖌 Xem nét
          </Button>
          <Button
            className="gap-1.5 bg-amber-500 hover:bg-amber-600 text-white"
            onClick={handleWriteQuiz}
            disabled={writeMode === 'quiz'}
          >
            ✏️ Luyện viết
          </Button>
          <Button
            variant="ghost"
            className="gap-1.5 text-gray-500 hover:text-gray-700"
            onClick={handleWriteReset}
          >
            🔄 Làm lại
          </Button>
        </div>

        {/* Next character */}
        {writeIsComplete && activeWordIndex < writingWords.length - 1 && (
          <div className="px-5 pb-4">
            <Button
              className="w-full bg-emerald-500 hover:bg-emerald-600 text-white gap-2"
              onClick={goNextWord}
            >
              Chữ tiếp theo: {getDisplayChar(writingWords[activeWordIndex + 1], script)} →
            </Button>
          </div>
        )}
      </div>
    );
  };

  // ─── RENDER: Reading Skill ───
  const renderReadingSkill = () => {
    if (!activeWord) return null;

    return (
      <div className="space-y-0">
        {/* Word display */}
        <div className="text-center py-6">
          <div className="text-5xl font-serif text-gray-800 mb-2">{displayChar}</div>
          {readShowPinyin && (
            <div className="text-lg text-amber-600 font-semibold animate-fade-in">{activeWord.pinyin}</div>
          )}
        </div>

        {/* Stats */}
        <div className="flex justify-center gap-6 pb-4">
          <div className="text-center">
            <div className="text-xl font-bold text-emerald-600">{readCorrect}</div>
            <div className="text-xs text-gray-500">Đúng</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-red-500">{readTotal - readCorrect}</div>
            <div className="text-xs text-gray-500">Sai</div>
          </div>
        </div>

        {/* Choices */}
        <div className="px-5 space-y-2 pb-4">
          {readChoices.map((choice, i) => {
            const isCorrectChoice = choice === activeWord.vietnamese;
            const isWrongSelection = readAnswer === 'wrong' && !isCorrectChoice;
            let btnClass = 'w-full text-left justify-start text-sm py-3 px-4 h-auto transition-all';
            if (readAnswer === null) {
              btnClass += ' hover:bg-amber-50 hover:border-amber-300';
            } else if (isCorrectChoice) {
              btnClass += ' bg-emerald-100 border-emerald-400 text-emerald-700';
            } else if (isWrongSelection) {
              btnClass += ' border-red-200 text-gray-400';
            } else {
              btnClass += ' text-gray-400';
            }

            return (
              <Button
                key={`read-${i}-${choice}`}
                variant="outline"
                className={btnClass}
                onClick={() => handleReadAnswer(choice)}
                disabled={readAnswer !== null}
              >
                <span className="mr-2 font-bold text-xs opacity-50">{String.fromCharCode(65 + i)}</span>
                {choice}
                {readAnswer !== null && isCorrectChoice && <span className="ml-auto">✅</span>}
                {readAnswer !== null && !isCorrectChoice && readAnswer === 'wrong' && <span className="ml-auto">❌</span>}
              </Button>
            );
          })}
        </div>

        {/* Next / Skip */}
        {readAnswer && (
          <div className="px-5 pb-4 animate-fade-in">
            <Button
              className="w-full bg-amber-500 hover:bg-amber-600 text-white"
              onClick={() => {
                if (activeWordIndex < currentWordList.length - 1) {
                  handleWordSelect(activeWordIndex + 1);
                } else {
                  handleWordSelect(0);
                }
              }}
            >
              {activeWordIndex < currentWordList.length - 1 ? 'Từ tiếp theo →' : 'Bắt đầu lại ↻'}
            </Button>
          </div>
        )}

        {!readAnswer && (
          <div className="px-5 pb-4">
            <Button
              variant="ghost"
              className="w-full text-gray-500"
              onClick={goNextWord}
            >
              Bỏ qua →
            </Button>
          </div>
        )}
      </div>
    );
  };

  // ─── RENDER: Listening Skill ───
  const renderListeningSkill = () => {
    if (!activeWord) return null;

    return (
      <div className="space-y-0">
        {/* Play button */}
        <div className="text-center py-6">
          <Button
            size="lg"
            className={`w-20 h-20 rounded-full text-3xl shadow-lg ${
              listenPlaying
                ? 'bg-amber-600 animate-pulse'
                : 'bg-amber-500 hover:bg-amber-600 text-white'
            }`}
            onClick={handleListenPlay}
            disabled={listenAudioLoading}
          >
            {listenAudioLoading ? (
              <span className="text-lg">⏳</span>
            ) : listenPlaying ? (
              <span className="text-lg">🔊</span>
            ) : (
              '▶️'
            )}
          </Button>
          <p className="mt-2 text-sm text-gray-500">
            {listenAudioLoading ? 'Đang tải âm thanh...' : 'Nhấn để nghe'}
          </p>
        </div>

        {/* Stats */}
        <div className="flex justify-center gap-6 pb-4">
          <div className="text-center">
            <div className="text-xl font-bold text-emerald-600">{listenCorrect}</div>
            <div className="text-xs text-gray-500">Đúng</div>
          </div>
          <div className="text-center">
            <div className="text-xl font-bold text-red-500">{listenTotal - listenCorrect}</div>
            <div className="text-xs text-gray-500">Sai</div>
          </div>
        </div>

        {/* Choices */}
        <div className="px-5 space-y-2 pb-4">
          {listenChoices.map((choice, i) => {
            const choiceChar = getDisplayChar(choice, script);
            const isCorrectChoice = choice.simplified === activeWord.simplified;
            let btnClass = 'w-full text-center py-3 px-4 h-auto transition-all text-lg font-serif';
            if (listenAnswer === null) {
              btnClass += ' hover:bg-amber-50 hover:border-amber-300';
            } else if (isCorrectChoice) {
              btnClass += ' bg-emerald-100 border-emerald-400 text-emerald-700';
            } else {
              btnClass += ' text-gray-400';
            }

            return (
              <Button
                key={`listen-${i}-${choice.simplified}`}
                variant="outline"
                className={btnClass}
                onClick={() => handleListenAnswer(choice)}
                disabled={listenAnswer !== null}
              >
                {choiceChar}
                {listenAnswer !== null && isCorrectChoice && <span className="ml-2 text-sm">✅</span>}
              </Button>
            );
          })}
        </div>

        {/* Show info after answering */}
        {listenShowInfo && (
          <div className="px-5 pb-4 animate-fade-in">
            <div className="bg-amber-50 rounded-xl p-4 text-center border border-amber-100">
              <div className="text-2xl font-serif text-gray-800 mb-1">{displayChar}</div>
              <div className="text-amber-600 font-semibold">{activeWord.pinyin}</div>
              <div className="text-sm text-gray-500">{activeWord.vietnamese}</div>
            </div>
          </div>
        )}

        {/* Next / Skip */}
        {listenAnswer && (
          <div className="px-5 pb-4 animate-fade-in">
            <Button
              className="w-full bg-amber-500 hover:bg-amber-600 text-white"
              onClick={() => {
                if (activeWordIndex < currentWordList.length - 1) {
                  handleWordSelect(activeWordIndex + 1);
                } else {
                  handleWordSelect(0);
                }
              }}
            >
              {activeWordIndex < currentWordList.length - 1 ? 'Từ tiếp theo →' : 'Bắt đầu lại ↻'}
            </Button>
          </div>
        )}

        {!listenAnswer && (
          <div className="px-5 pb-4">
            <Button
              variant="ghost"
              className="w-full text-gray-500"
              onClick={goNextWord}
            >
              Bỏ qua →
            </Button>
          </div>
        )}
      </div>
    );
  };

  // ─── RENDER: Speaking Skill ───
  const renderSpeakingSkill = () => {
    if (!activeWord) return null;

    return (
      <div className="space-y-0">
        {/* Word display */}
        <div className="text-center py-6">
          <div className="text-5xl font-serif text-gray-800 mb-2">{displayChar}</div>
          <div className="text-lg text-amber-600 font-semibold">{activeWord.pinyin}</div>
          <div className="text-sm text-gray-500">{activeWord.vietnamese}</div>
        </div>

        {/* Play reference audio */}
        <div className="flex justify-center pb-4">
          <Button
            variant="outline"
            className="gap-2 border-amber-200 hover:bg-amber-50 hover:text-amber-700"
            onClick={handleSpeakPlay}
            disabled={speakAudioLoading || speakPlaying}
          >
            {speakAudioLoading ? '⏳ Đang tải...' : speakPlaying ? '🔊 Đang phát...' : '🔊 Nghe mẫu'}
          </Button>
        </div>

        <Separator className="mx-5" />

        {/* Record section */}
        <div className="text-center py-6">
          {!speakRecording ? (
            <Button
              size="lg"
              className="w-20 h-20 rounded-full text-3xl shadow-lg bg-red-500 hover:bg-red-600 text-white"
              onClick={handleStartRecording}
              disabled={speakLoading}
            >
              {speakLoading ? (
                <span className="text-lg">⏳</span>
              ) : (
                '🎤'
              )}
            </Button>
          ) : (
            <Button
              size="lg"
              className="w-20 h-20 rounded-full text-3xl shadow-lg bg-red-600 text-white animate-pulse"
              onClick={handleStopRecording}
            >
              <span className="relative flex h-6 w-6">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-6 w-6 bg-red-300 items-center justify-center text-xs font-bold">⏹</span>
              </span>
            </Button>
          )}
          <p className="mt-2 text-sm text-gray-500">
            {speakLoading
              ? 'Đang nhận diện...'
              : speakRecording
                ? '🔴 Đang ghi âm... Nhấn để dừng'
                : 'Nhấn để ghi âm'}
          </p>
        </div>

        {/* Result */}
        {speakResult && (
          <div className="px-5 pb-4 animate-fade-in">
            <div className={`rounded-xl p-4 text-center border ${
              speakResult === 'correct'
                ? 'bg-emerald-50 border-emerald-200'
                : 'bg-red-50 border-red-200'
            }`}>
              <div className="text-2xl mb-1">
                {speakResult === 'correct' ? '🎉' : '😊'}
              </div>
              <div className={`text-lg font-bold ${
                speakResult === 'correct' ? 'text-emerald-700' : 'text-red-700'
              }`}>
                {speakResult === 'correct' ? 'Chính xác!' : 'Thử lại nhé!'}
              </div>
              {speakResult === 'wrong' && speakRecognized && (
                <p className="text-sm text-gray-500 mt-1">
                  Bạn nói: <span className="font-serif font-semibold">{speakRecognized}</span>
                </p>
              )}
            </div>
          </div>
        )}

        {/* Retry / Next */}
        <div className="px-5 pb-4 space-y-2">
          {speakResult && (
            <Button
              className="w-full bg-amber-500 hover:bg-amber-600 text-white"
              onClick={() => {
                if (speakResult === 'correct') {
                  goNextWord();
                } else {
                  setSpeakResult(null);
                  setSpeakRecognized('');
                }
              }}
            >
              {speakResult === 'correct' ? 'Từ tiếp theo →' : 'Thử lại ↻'}
            </Button>
          )}
          {!speakResult && !speakRecording && !speakLoading && (
            <Button
              variant="ghost"
              className="w-full text-gray-500"
              onClick={goNextWord}
            >
              Bỏ qua →
            </Button>
          )}
        </div>
      </div>
    );
  };

  // ─── RENDER: Skill Content ───
  const renderSkillContent = () => {
    switch (skill) {
      case 'writing':
        return renderWritingSkill();
      case 'reading':
        return renderReadingSkill();
      case 'listening':
        return renderListeningSkill();
      case 'speaking':
        return renderSpeakingSkill();
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-amber-50 via-white to-orange-50">
      {renderHeader()}

      {/* Main Content */}
      <main className="flex-1 max-w-2xl mx-auto w-full px-4 py-4 space-y-4">
        {/* Skill Tabs */}
        {renderSkillTabs()}

        {/* Topic Tabs */}
        {renderTopicTabs()}

        {/* Word Selector */}
        {renderWordSelector()}

        {/* Main Card */}
        {activeWord && (
          <div className="bg-white rounded-2xl shadow-lg border border-amber-100 overflow-hidden">
            {renderSkillContent()}
            {renderPanda()}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="text-center py-3 text-xs text-gray-400">
        Luyện Tập Chữ Hán · Học tiếng Trung mỗi ngày 🐼
      </footer>

      {/* Global CSS Animations */}
      <style jsx global>{`
        @keyframes panda-bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-8px); }
        }
        @keyframes panda-idle {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-3px); }
        }
        @keyframes fade-in {
          from { opacity: 0; transform: scale(0.9); }
          to { opacity: 1; transform: scale(1); }
        }
        .panda-avatar {
          animation: panda-idle 3s ease-in-out infinite;
        }
        .animate-fade-in {
          animation: fade-in 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
