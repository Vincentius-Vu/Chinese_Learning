import type { Metadata } from "next";
import { Geist, Geist_Mono, Noto_Serif_SC } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const notoSerifSC = Noto_Serif_SC({
  variable: "--font-noto-serif-sc",
  subsets: ["latin"],
  weight: ["400", "700"],
});

export const metadata: Metadata = {
  title: "Luyện Tập Chữ Hán - 4 Kỹ năng Nghe Nói Đọc Viết",
  description: "Ứng dụng học tiếng Trung với 4 kỹ năng Nghe, Nói, Đọc, Viết. Hỗ trợ HSK 1 (Giản thể) và TOCFL 1 (Phồn thể).",
  keywords: ["học tiếng Trung", "luyện viết chữ Hán", "HSK 1", "TOCFL 1", "nét bút", "Hanzi Writer", "nghe nói đọc viết"],
  openGraph: {
    title: "Luyện Viết Chữ Hán",
    description: "Học viết chữ Hán đúng thứ tự nét bút",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="vi" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${notoSerifSC.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
